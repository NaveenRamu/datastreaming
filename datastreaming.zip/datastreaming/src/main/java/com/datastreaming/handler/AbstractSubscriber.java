package com.datastreaming.handler;

import io.netty.buffer.ByteBuf;
import org.reactivestreams.Subscriber;
import org.reactivestreams.Subscription;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ratpack.core.handling.Context;

public abstract class AbstractSubscriber implements Subscriber<ByteBuf> {

  private final Logger logger = LoggerFactory.getLogger(AbstractSubscriber.class);

  protected Context ctx;
  protected Subscription subscription;
  protected boolean isError;
  protected Throwable cause;
  protected String key;
  protected String topic;
  protected String topicName;
  protected String pulsarTenantName;
  protected String pulsarTenantNamespace;

  public String getTenantName() {
    return tenantName;
  }

  public void setTenantName(String tenantName) {
    this.tenantName = tenantName;
  }

  protected String tenantName;

  public String getPulsarTenantName() {
    return pulsarTenantName;
  }

  public void setPulsarTenantName(String pulsarTenantName) {
    this.pulsarTenantName = pulsarTenantName;
  }

  public String getPulsarTenantNamespace() {
    return pulsarTenantNamespace;
  }

  public void setPulsarTenantNamespace(String pulsarTenantNamespace) {
    this.pulsarTenantNamespace = pulsarTenantNamespace;
  }

  private static final String DEFAULT_CHARSET = "UTF-8";

  public String getKey() {
    return key;
  }

  public void setKey(String key) {
    this.key = key;
  }

  public void setTopic(String topic) {
    this.topic = topic;
  }

  protected AbstractSubscriber(Context ctx) {
    this.ctx = ctx;
  }

  protected AbstractSubscriber() {}

  @Override
  public void onSubscribe(Subscription subscription) {
    logger.info("onSubscribe");
    System.out.println("onSubscribe");
    this.subscription = subscription;
    subscription.request(1);
  }

  @Override
  public void onNext(ByteBuf byteBuf) {
    logger.info("onNext");
    System.out.println("onNext");
    process(byteBuf);
    if (!isError) {
      byteBuf.release();
      subscription.request(1);
    } else {
      byteBuf.release();
      subscription.cancel();
      ctx.error(cause);
    }
  }

  @Override
  public void onError(Throwable throwable) {
    logger.debug("onError");
    ctx.error(throwable);
  }

  @Override
  public void onComplete() {
    logger.info("Thread name [{}], onComplete", Thread.currentThread().getName());
    System.out.println("onComplete");
    requestComplete();
    ctx.getResponse().status(200).send("Success");
    }

  protected abstract void process(ByteBuf byteBuf);

  protected void error(Throwable throwable) {
    isError = true;
    cause = throwable;
  }

  protected abstract void requestComplete();

  public String getTopicName() {
    return topicName;
  }

}
