package com.datastreaming.handler;

import com.datastreaming.subscriber.JsonSubscriber;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ratpack.core.handling.Context;
import ratpack.core.http.Headers;
import ratpack.core.http.HttpMethod;


public class GlobalHandler extends AbstractHandler {
  private static final Logger logger = LoggerFactory.getLogger(GlobalHandler.class);

  @Override
  public void handleRequest(Context context) throws Exception {
    HttpMethod httpMethod = context.getRequest().getMethod();
    Headers headers = context.getRequest().getHeaders();
    AbstractSubscriber jsonSubscriber = new JsonSubscriber(context);
    context.getRequest().getBodyStream().subscribe(jsonSubscriber);
  }

}
